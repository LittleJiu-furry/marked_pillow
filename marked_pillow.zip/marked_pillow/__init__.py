'''
    Marked Pillow 是一个利用html+css标记语言来实现更方便绘图效果的一个绘图工具

    你可以通过html+css更加简单的来实现更加丰富的绘图效果

    针对于自封闭标签，此模块要求必须使用/>来结束标签

    Written by Little_Jiu

'''

__version__ = '0.1.0'
__author__ = 'Little_Jiu'
__license__ = 'LGPL-3.0'

from PIL import Image, ImageDraw, ImageFont
import re


        
    





    


    
    
