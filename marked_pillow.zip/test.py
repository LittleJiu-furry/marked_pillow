from marked_pillow.html import Document
import time

s = time.time()
document = Document()
html_content = ""
with open("test.html", "r", encoding="utf-8") as f:
    html_content = f.read()

# html_content = html_content.replace("\n", "").strip()

document.parserHTML(html_content)
e = time.time()
print(e-s)